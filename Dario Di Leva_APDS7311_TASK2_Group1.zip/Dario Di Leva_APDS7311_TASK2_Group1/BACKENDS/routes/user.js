// Import necessary modules
const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Registration (Signup) Route
router.post('/signup', (req, res) => {
  // Hash the user's password
  bcrypt.hash(req.body.password, 10)
    .then(hash => {
      const user = new User({
        Username: req.body.Username,
        FirstName: req.body.FirstName,
        Surname: req.body.Surname,
        password: hash
      });

      // Save the user to the database
      return user.save();
    })
    .then(result => {
      res.status(201).json({
        message: 'User Created',
        result: result
      });
    })
    .catch(err => {
      res.status(500).json({
        error: err
      });
    });
});

// Login Route
router.post('/login', (req, res) => {
  let fetchedUser;

  // Find the user by username
  User.findOne({ Username: req.body.Username })
    .then(user => {
      if (!user) {
        return res.status(401).json({
          message: "Username not found"
        });
      }

      // Store the found user
      fetchedUser = user;

      // Compare the provided password with the hashed password in the database
      return bcrypt.compare(req.body.password, user.password);
    })
    .then(result => {
      if (!result) {
        return res.status(401).json({
          message: "Incorrect password"
        });
      }

      // Create a JWT token
      const token = jwt.sign(
        { Username: fetchedUser.Username, userId: fetchedUser._id },
        'SuperSecretPassword',
        { expiresIn: '1 day' }
      );

      res.status(200).json({ token: token });
    })
    .catch(err => {
      return res.status(401).json({
        message: "Authentication Failure"
      });
    });
});

module.exports = router;