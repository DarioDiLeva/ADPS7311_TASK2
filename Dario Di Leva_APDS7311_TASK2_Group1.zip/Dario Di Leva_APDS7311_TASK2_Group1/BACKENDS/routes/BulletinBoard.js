const express = require('express');
const router = express.Router();
const Bulletin = require('../models/BulletinBoard');
const chechauth = require('../middleware/CheckAuth'); // Checking authentication

// GET route to retrieve all bulletins, protected by authentication middleware
router.get('', chechauth, (req, res) => {
    Bulletin.find().then((Bulletin) => {
        res.json({
            message: 'Description Found',
            Bulletin: Bulletin
        });
    });
});

// POST route to create a new bulletin, protected by authentication middleware
router.post('', chechauth, (req, res) => {
    const bullet = new Bulletin({
        Id: req.body.Id,
        Title: req.body.Title,
        description: req.body.description,
    });

    bullet.save().then(() => {
        res.status(201).json({
            message: 'Description Created',
            bullet: bullet
        });
    });
});

// DELETE route to delete a bulletin by ID, protected by authentication middleware
router.delete('/:id', chechauth, (req, res) => {
    Bulletin.deleteOne({ _id: req.params.id }).then((result) => {
        res.status(200).json({ message: 'Description Deleted' });
    });
});

module.exports = router;