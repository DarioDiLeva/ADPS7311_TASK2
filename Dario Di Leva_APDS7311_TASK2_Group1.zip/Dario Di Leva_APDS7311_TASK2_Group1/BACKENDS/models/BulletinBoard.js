const mongoose = require('mongoose');

// Define the bulletin schema
const bulletinSchema = mongoose.Schema({
    Id: { type: String, required: true },
    Title: { type: String, required: true },
    description: { type: String, required: true }
});

// Create and export the Bulletin model based on the schema
module.exports = mongoose.model("Bulletin", bulletinSchema);