const mongoose = require('mongoose');

// Define the user schema
const userSchema = mongoose.Schema({
  Username: { type: String, required: true },
  FirstName: { type: String, required: true },
  Surname: { type: String, required: true },
  password: { type: String, required: true }
});

// Create and export the User model based on the schema
module.exports = mongoose.model("User", userSchema);
