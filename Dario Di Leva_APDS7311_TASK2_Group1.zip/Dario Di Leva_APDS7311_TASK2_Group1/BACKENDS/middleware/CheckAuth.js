const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  try {
    // Extract the JWT from the 'Authorization' header
    const token = req.headers.authorization;

    // Verify the JWT using a secret key ('SuperSecretPassword' in this case)
    jwt.verify(token, "SuperSecretPassword");

    // If the JWT is valid, continue to the next middleware or route handler
    next();
  } catch (error) {
    // If there's an error, such as an expired or invalid token, respond with a 401 Unauthorized status
    res.status(401).json({
      message: "Invalid token"
    });
  }
};