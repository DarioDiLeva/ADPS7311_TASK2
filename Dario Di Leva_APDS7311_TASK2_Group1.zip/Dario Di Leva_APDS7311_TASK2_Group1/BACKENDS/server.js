const https = require('https'); // Import the 'https' module.
const app = require('./app'); // Import your Express app.
const fs = require('fs'); // Import the 'fs' module to read files.

const port = 7001; // Specify the port you want to listen on.

// Create an HTTPS server using the SSL/TLS certificates.
const server = https.createServer(
  {
    key: fs.readFileSync('keys/privatekey.pem'), // Read the private key from a file.
    cert: fs.readFileSync('keys/certificate.pem'), // Read the SSL certificate from a file.
  },
  app // Pass your Express app as the request handler.
);

// Start the server and listen on the specified port.
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});