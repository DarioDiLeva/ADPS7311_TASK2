// Import necessary modules
const express = require('express');
const app = express();
const urlprefix = '/api';
const mongoose = require('mongoose');
const fs = require('fs');
const cert = fs.readFileSync('keys/certificate.pem');
const options = { server: { sslCA: cert } };
const dbConnectionString = 'mongodb+srv://DarioDiLeva:Dropweek38@databasesecurity.hybykx2.mongodb.net/?retryWrites=true&w=majority';
const BulletinRoutes = require('./routes/BulletinBoard');
const UserRoutes = require('./routes/user');

// Connect to MongoDB using the provided connection string
mongoose
  .connect(dbConnectionString)
  .then(() => {
    console.log('Connected :-)'); // Connection successful
  })
  .catch(() => {
    console.log('Not Connected :-('); // Connection failed
  }, options);

// Parse JSON requests
app.use(express.json());

// Enable CORS (Cross-Origin Resource Sharing) for all routes
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.setHeader('Access-Control-Allow-Methods', '*');
  next();
});

// Mount the routes with the specified URL prefixes
app.use(urlprefix + '/Bulletin', BulletinRoutes);
app.use(urlprefix + '/User', UserRoutes);

// Export the Express app for use in your application
module.exports = app;